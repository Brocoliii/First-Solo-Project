using UnityEngine;
using System.Collections.Generic; 

public class ItemRandomizer : MonoBehaviour
{
    [Header("�ͧ�Ӥѭ 5 ���ҧ (Key Items)")]
    public Transform[] keyItems;

    [Header("�ش�Դ�������� (Spawn Points)")]
    public Transform[] spawnPoints; 

    void Start()
    {
        ShuffleAndSpawn();
    }

    void ShuffleAndSpawn()
    {
        if (spawnPoints.Length < keyItems.Length)
        {
            Debug.LogError("Error: �ش�Դ (Spawn Points) ���¡��Ҩӹǹ�ͧ! ���ҧ������ǹ");
            return;
        }

        List<Transform> availablePoints = new List<Transform>(spawnPoints);

        foreach (Transform item in keyItems)
        {
            if (item == null) continue;

            int randomIndex = Random.Range(0, availablePoints.Count);
            Transform randomPoint = availablePoints[randomIndex];

            item.position = randomPoint.position;
            item.rotation = randomPoint.rotation; 
            Debug.Log(item.name + " ������Դ��� " + randomPoint.name);

            availablePoints.RemoveAt(randomIndex);
        }
    }
}